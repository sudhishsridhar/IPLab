import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
public class DBPrg3 extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String name=req.getParameter("txt");
Connection con;
Statement stmt;
PreparedStatement ps;
final String DB_URL="jdbc:mysql://localhost:3306/temp";
final String USER="root";
final String PASS="ssn";
try{
con=DriverManager.getConnection(DB_URL,USER,PASS);
stmt=con.createStatement();
String sql;

sql="Delete from student where Name=?";
ps=con.prepareStatement(sql);
ps.setString(1,name);
ps.execute();
sql="select* from student";
ResultSet rs=stmt.executeQuery(sql);
pw.println("<html>");
pw.println("<body>");
pw.println("<p>" +"After Deletion" +"<p>");
while(rs.next())
{
pw.println("<p>"+rs.getInt("Rno")+"</p>"+"<p>"+rs.getString("Name")+"</p>");
}
pw.println("</body>");
pw.println("</html>");
}
catch(Exception E){
pw.println("<html>");
pw.println("<body>");
pw.println(E.toString());
pw.println("</body>");
pw.println("</html>");
}
}
}
