import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
public class HelloPrg extends HttpServlet
{
public void doGet(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
{
res.setContentType("text/html");
PrintWriter pw=res.getWriter();
String name=req.getParameter("txt");
pw.println("<html>");
pw.println("<body>");
pw.println("<p style=\"color:red;\">Hello World"+"</p>");
pw.println("</body>");
pw.println("</html>");
}
}
